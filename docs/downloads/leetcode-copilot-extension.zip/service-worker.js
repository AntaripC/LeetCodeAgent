// src/solver/language-registry.ts
var SUPPORTED_LANGUAGES = [
  {
    id: "python3",
    displayName: "Python 3",
    monacoLanguageId: "python",
    aliases: ["python3", "python", "py"],
    fileExtension: ".py",
    commentPrefix: "#",
    typicalBoilerplate: "class Solution:\n    def solve(self) -> None:\n        pass\n",
    standardImports: ["from typing import List, Optional, Dict, Set, Tuple", "import collections", "import heapq"]
  },
  {
    id: "cpp",
    displayName: "C++",
    monacoLanguageId: "cpp",
    aliases: ["cpp", "c++", "g++"],
    fileExtension: ".cpp",
    commentPrefix: "//",
    typicalBoilerplate: "class Solution {\npublic:\n    void solve() {\n        \n    }\n};",
    standardImports: ["#include <vector>", "#include <string>", "#include <unordered_map>", "#include <algorithm>", "using namespace std;"]
  },
  {
    id: "java",
    displayName: "Java",
    monacoLanguageId: "java",
    aliases: ["java"],
    fileExtension: ".java",
    commentPrefix: "//",
    typicalBoilerplate: "class Solution {\n    public void solve() {\n        \n    }\n}",
    standardImports: ["import java.util.*;"]
  },
  {
    id: "c",
    displayName: "C",
    monacoLanguageId: "c",
    aliases: ["c"],
    fileExtension: ".c",
    commentPrefix: "//",
    typicalBoilerplate: "void solve() {\n    \n}",
    standardImports: ["#include <stdio.h>", "#include <stdlib.h>", "#include <string.h>", "#include <stdbool.h>"]
  },
  {
    id: "csharp",
    displayName: "C#",
    monacoLanguageId: "csharp",
    aliases: ["csharp", "c#", "cs"],
    fileExtension: ".cs",
    commentPrefix: "//",
    typicalBoilerplate: "public class Solution {\n    public void Solve() {\n        \n    }\n}",
    standardImports: ["using System;", "using System.Collections.Generic;"]
  },
  {
    id: "javascript",
    displayName: "JavaScript",
    monacoLanguageId: "javascript",
    aliases: ["javascript", "js"],
    fileExtension: ".js",
    commentPrefix: "//",
    typicalBoilerplate: "/**\n * @return {void}\n */\nvar solve = function() {\n    \n};",
    standardImports: []
  },
  {
    id: "typescript",
    displayName: "TypeScript",
    monacoLanguageId: "typescript",
    aliases: ["typescript", "ts"],
    fileExtension: ".ts",
    commentPrefix: "//",
    typicalBoilerplate: "function solve(): void {\n    \n};",
    standardImports: []
  },
  {
    id: "go",
    displayName: "Go",
    monacoLanguageId: "go",
    aliases: ["go", "golang"],
    fileExtension: ".go",
    commentPrefix: "//",
    typicalBoilerplate: "func solve() {\n    \n}",
    standardImports: ["package main", 'import "fmt"']
  },
  {
    id: "rust",
    displayName: "Rust",
    monacoLanguageId: "rust",
    aliases: ["rust", "rs"],
    fileExtension: ".rs",
    commentPrefix: "//",
    typicalBoilerplate: "impl Solution {\n    pub fn solve() {\n        \n    }\n}",
    standardImports: []
  },
  {
    id: "kotlin",
    displayName: "Kotlin",
    monacoLanguageId: "kotlin",
    aliases: ["kotlin", "kt"],
    fileExtension: ".kt",
    commentPrefix: "//",
    typicalBoilerplate: "class Solution {\n    fun solve() {\n        \n    }\n}",
    standardImports: []
  },
  {
    id: "swift",
    displayName: "Swift",
    monacoLanguageId: "swift",
    aliases: ["swift"],
    fileExtension: ".swift",
    commentPrefix: "//",
    typicalBoilerplate: "class Solution {\n    func solve() {\n        \n    }\n}",
    standardImports: ["import Foundation"]
  },
  {
    id: "php",
    displayName: "PHP",
    monacoLanguageId: "php",
    aliases: ["php"],
    fileExtension: ".php",
    commentPrefix: "//",
    typicalBoilerplate: "class Solution {\n    function solve() {\n        \n    }\n}",
    standardImports: []
  },
  {
    id: "ruby",
    displayName: "Ruby",
    monacoLanguageId: "ruby",
    aliases: ["ruby", "rb"],
    fileExtension: ".rb",
    commentPrefix: "#",
    typicalBoilerplate: "def solve()\n    \nend",
    standardImports: []
  },
  {
    id: "dart",
    displayName: "Dart",
    monacoLanguageId: "dart",
    aliases: ["dart"],
    fileExtension: ".dart",
    commentPrefix: "//",
    typicalBoilerplate: "class Solution {\n    void solve() {\n        \n    }\n}",
    standardImports: []
  },
  {
    id: "scala",
    displayName: "Scala",
    monacoLanguageId: "scala",
    aliases: ["scala"],
    fileExtension: ".scala",
    commentPrefix: "//",
    typicalBoilerplate: "object Solution {\n    def solve(): Unit = {\n        \n    }\n}",
    standardImports: []
  }
];
var LanguageRegistry = class {
  static languageMap = /* @__PURE__ */ new Map();
  static {
    for (const lang of SUPPORTED_LANGUAGES) {
      this.languageMap.set(lang.id.toLowerCase(), lang);
      for (const alias of lang.aliases) {
        this.languageMap.set(alias.toLowerCase(), lang);
      }
    }
  }
  static getAll() {
    return SUPPORTED_LANGUAGES;
  }
  static findByIdOrAlias(identifier) {
    if (!identifier) return void 0;
    const clean = identifier.trim().toLowerCase().replace(/[^a-z0-9#+]/g, "");
    return this.languageMap.get(clean);
  }
  static normalizeLanguageId(identifier) {
    const found = this.findByIdOrAlias(identifier);
    return found ? found.id : "python3";
  }
  static getDisplayName(identifier) {
    const found = this.findByIdOrAlias(identifier);
    return found ? found.displayName : identifier;
  }
  static getMonacoLanguageId(identifier) {
    const found = this.findByIdOrAlias(identifier);
    return found ? found.monacoLanguageId : "plaintext";
  }
  static areLanguagesCompatible(lang1, lang2) {
    const l1 = this.findByIdOrAlias(lang1);
    const l2 = this.findByIdOrAlias(lang2);
    if (!l1 || !l2) return false;
    return l1.id === l2.id;
  }
  /**
   * Validates if the given code has basic syntax hygiene for the target language.
   */
  static validateCodeHygiene(code, languageId) {
    if (!code || code.trim().length === 0) {
      return { valid: false, reason: "Generated code is empty" };
    }
    const trimmed = code.trim();
    if (trimmed.startsWith("```") || trimmed.endsWith("```")) {
      return { valid: false, reason: "Code contains raw markdown code fence markers" };
    }
    const cStyleLanguages = ["cpp", "c", "java", "csharp", "javascript", "typescript", "rust", "kotlin", "swift", "php", "dart", "scala", "go"];
    const norm = this.normalizeLanguageId(languageId);
    if (cStyleLanguages.includes(norm)) {
      let curly = 0;
      let square = 0;
      let round = 0;
      let inString = false;
      let stringChar = "";
      let inLineComment = false;
      let inBlockComment = false;
      for (let i = 0; i < trimmed.length; i++) {
        const ch = trimmed[i];
        const next = trimmed[i + 1] || "";
        if (!inString && !inBlockComment && ch === "/" && next === "/") {
          inLineComment = true;
          i++;
          continue;
        }
        if (inLineComment && ch === "\n") {
          inLineComment = false;
          continue;
        }
        if (!inString && !inLineComment && ch === "/" && next === "*") {
          inBlockComment = true;
          i++;
          continue;
        }
        if (inBlockComment && ch === "*" && next === "/") {
          inBlockComment = false;
          i++;
          continue;
        }
        if (inLineComment || inBlockComment) continue;
        if ((ch === '"' || ch === "'" || ch === "`") && (i === 0 || trimmed[i - 1] !== "\\")) {
          if (!inString) {
            inString = true;
            stringChar = ch;
          } else if (stringChar === ch) {
            inString = false;
          }
          continue;
        }
        if (inString) continue;
        if (ch === "{") curly++;
        else if (ch === "}") curly--;
        else if (ch === "[") square++;
        else if (ch === "]") square--;
        else if (ch === "(") round++;
        else if (ch === ")") round--;
        if (curly < 0 || square < 0 || round < 0) {
          return { valid: false, reason: `Unmatched closing bracket '${ch}' found in code` };
        }
      }
      if (curly !== 0) return { valid: false, reason: `Unbalanced curly braces { } (count difference: ${curly})` };
      if (round !== 0) return { valid: false, reason: `Unbalanced parentheses ( ) (count difference: ${round})` };
    }
    return { valid: true };
  }
};

// src/solver/prompt-builder.ts
var PromptBuilder = class {
  static buildPrompt(req) {
    const langInfo = LanguageRegistry.findByIdOrAlias(req.targetLanguage) || {
      id: req.targetLanguage,
      displayName: req.targetLanguage,
      typicalBoilerplate: ""
    };
    const systemInstruction = `You are a world-class competitive programmer, algorithms expert, and LeetCode master.
Your goal is to provide accurate, clean, production-grade solutions strictly formatted as a JSON object.

CRITICAL INSTRUCTIONS:
1. Always write code compatible with the required LeetCode method and class signatures.
2. DO NOT include unnecessary main() or entry point functions unless the problem explicitly demands it.
3. DO NOT wrap the code in excessive explanatory comments inside the code block. Keep code pure and readable.
4. Output MUST BE a valid JSON object matching this schema exactly:
{
  "problemSummary": "A concise 1-2 sentence summary of the core objective and inputs/outputs",
  "algorithm": "Clear, step-by-step explanation of the chosen data structures and algorithm",
  "correctness": "Why this algorithm is mathematically correct and handles invariant properties",
  "code": "The complete, standalone, ready-to-run code in the requested language matching the LeetCode signature",
  "language": "${langInfo.id}",
  "timeComplexity": "O(...) with precise explanation",
  "spaceComplexity": "O(...) with precise explanation",
  "edgeCases": ["List of specific handled edge cases, e.g. empty inputs, negative numbers, duplicates"],
  "assumptions": ["List of any assumptions or explicit constraints used"]
}
5. Return ONLY the raw JSON object. Do not wrap in markdown quotes if possible, or if wrapping, use \`\`\`json.`;
    let actionSpecificInstructions = "";
    switch (req.action) {
      case "solve":
        actionSpecificInstructions = `TASK: SOLVE THIS PROBLEM
Provide the optimal time and space complexity solution in ${langInfo.displayName}.
Respect the required class or function signature shown in the starter code.`;
        break;
      case "explain":
        actionSpecificInstructions = `TASK: DEEP EXPLANATION & INTUITION
Provide an in-depth breakdown of the optimal intuition, algorithmic paradigm (e.g. Two Pointers, DP, Monotonic Stack), and trade-offs.
Include the optimal implementation in ${langInfo.displayName}.`;
        break;
      case "optimize":
        actionSpecificInstructions = `TASK: OPTIMIZE EXISTING CODE
Here is the user's current code:
\`\`\`${langInfo.id}
${req.userCurrentCode || req.problem.starterCode || "// No existing code provided"}
\`\`\`
Analyze time/space bottlenecks in the above code and supply an asymptotically faster or space-optimal solution in ${langInfo.displayName}.`;
        break;
      case "debug":
        actionSpecificInstructions = `TASK: DEBUG & FIX USER CODE
Here is the user's code with bugs or failing edge cases:
\`\`\`${langInfo.id}
${req.userCurrentCode || req.problem.starterCode || "// No existing code provided"}
\`\`\`
Identify the exact root causes of bugs, off-by-one errors, or wrong outputs, and provide the corrected, passing code in ${langInfo.displayName}.`;
        break;
    }
    const userPrompt = `Target Language: ${langInfo.displayName} (${langInfo.id})

Problem Title: ${req.problem.title}
Difficulty: ${req.problem.difficulty || "Unknown"}
URL: ${req.problem.url}

=== PROBLEM STATEMENT ===
${req.problem.statement}

=== EXAMPLES ===
${req.problem.examples && req.problem.examples.length > 0 ? req.problem.examples.join("\n\n") : "See statement above"}

=== CONSTRAINTS ===
${req.problem.constraints && req.problem.constraints.length > 0 ? req.problem.constraints.join("\n") : "Standard LeetCode limits apply"}

=== LEETCODE STARTER CODE / SIGNATURE ===
\`\`\`${langInfo.id}
${req.problem.starterCode || langInfo.typicalBoilerplate || ""}
\`\`\`

${actionSpecificInstructions}

${req.customInstructions ? `Additional User Request: ${req.customInstructions}
` : ""}

Remember to return ONLY the valid JSON object with:
"problemSummary", "algorithm", "correctness", "code", "language", "timeComplexity", "spaceComplexity", "edgeCases", "assumptions".`;
    return { systemInstruction, userPrompt };
  }
};

// src/solver/response-validator.ts
var ResponseValidator = class {
  /**
   * Attempts to extract and parse a JSON object from raw model output.
   */
  static extractJSON(rawText) {
    if (!rawText || !rawText.trim()) {
      throw new Error("AI returned an empty response");
    }
    const trimmed = rawText.trim();
    try {
      return JSON.parse(trimmed);
    } catch {
    }
    const jsonFenceRegex = /```(?:json)?\s*([\s\S]*?)\s*```/i;
    const fenceMatch = trimmed.match(jsonFenceRegex);
    if (fenceMatch && fenceMatch[1]) {
      try {
        return JSON.parse(fenceMatch[1].trim());
      } catch {
      }
    }
    const firstBrace = trimmed.indexOf("{");
    const lastBrace = trimmed.lastIndexOf("}");
    if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
      const candidate = trimmed.substring(firstBrace, lastBrace + 1);
      try {
        return JSON.parse(candidate);
      } catch (err) {
        try {
          const cleaned = candidate.replace(/,\s*([}\]])/g, "$1").replace(/[\u0000-\u001F]+/g, " ");
          return JSON.parse(cleaned);
        } catch {
          throw new Error(`Failed to parse extracted JSON block: ${err.message}`);
        }
      }
    }
    throw new Error("No JSON object found in AI response");
  }
  /**
   * Cleans code string of accidental markdown wrappers.
   */
  static sanitizeCode(rawCode) {
    if (!rawCode) return "";
    let code = rawCode.trim();
    if (code.startsWith("```")) {
      const firstLineBreak = code.indexOf("\n");
      if (firstLineBreak !== -1) {
        code = code.substring(firstLineBreak + 1);
      } else {
        code = code.replace(/^```[a-zA-Z0-9_-]*/, "");
      }
    }
    if (code.endsWith("```")) {
      code = code.substring(0, code.length - 3);
    }
    return code.trim();
  }
  /**
   * Validates and sanitizes the parsed AI response.
   */
  static validate(rawText, expectedLanguage) {
    const errors = [];
    const warnings = [];
    let parsed;
    try {
      parsed = this.extractJSON(rawText);
    } catch (e) {
      return {
        isValid: false,
        errors: [`JSON Parsing error: ${e.message}`],
        warnings
      };
    }
    if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
      return {
        isValid: false,
        errors: ["AI response root must be a JSON object"],
        warnings
      };
    }
    if (!parsed.code || typeof parsed.code !== "string" || !parsed.code.trim()) {
      errors.push('AI response is missing the "code" field or it is empty');
    }
    const sanitizedCode = this.sanitizeCode(parsed.code || "");
    const targetLang = parsed.language || expectedLanguage || "python3";
    const hygieneCheck = LanguageRegistry.validateCodeHygiene(sanitizedCode, targetLang);
    if (!hygieneCheck.valid) {
      warnings.push(`Code syntax hygiene warning: ${hygieneCheck.reason}`);
    }
    if (expectedLanguage && parsed.language) {
      const normExpected = LanguageRegistry.normalizeLanguageId(expectedLanguage);
      const normReceived = LanguageRegistry.normalizeLanguageId(parsed.language);
      if (normExpected !== normReceived) {
        warnings.push(`Expected solution in ${expectedLanguage}, but model tagged response as ${parsed.language}`);
      }
    }
    const edgeCases = Array.isArray(parsed.edgeCases) ? parsed.edgeCases.map((e) => String(e)) : parsed.edgeCases ? [String(parsed.edgeCases)] : [];
    const assumptions = Array.isArray(parsed.assumptions) ? parsed.assumptions.map((a) => String(a)) : parsed.assumptions ? [String(parsed.assumptions)] : [];
    const sanitizedResponse = {
      problemSummary: String(parsed.problemSummary || "Problem summary not provided by model."),
      algorithm: String(parsed.algorithm || "Algorithm explanation not provided."),
      correctness: String(parsed.correctness || "Correctness argument not provided."),
      code: sanitizedCode,
      language: targetLang,
      timeComplexity: String(parsed.timeComplexity || "O(?)"),
      spaceComplexity: String(parsed.spaceComplexity || "O(?)"),
      edgeCases,
      assumptions,
      rawResponse: rawText
    };
    return {
      isValid: errors.length === 0,
      errors,
      warnings,
      sanitizedResponse
    };
  }
};

// src/providers/gemini-provider.ts
var GeminiProvider = class _GeminiProvider {
  id = "gemini";
  name = "Google Gemini";
  static DEFAULT_MODELS = [
    { id: "gemini-4-argon", name: "Gemini 4 Argon (Latest Frontier Reasoning & Coding)", isDefault: true, isFrontierReasoning: true },
    { id: "gemini-3.8-flash", name: "Gemini 3.8 Flash (High Speed & Efficiency)" },
    { id: "gemini-2.0-flash", name: "Gemini 2.0 Flash" },
    { id: "gemini-1.5-pro", name: "Gemini 1.5 Pro" },
    { id: "gemini-1.5-flash", name: "Gemini 1.5 Flash" }
  ];
  resolveModel(settings) {
    let model = (settings.geminiCustomModel?.trim() || settings.selectedModel || settings.geminiModel || "gemini-4-argon").trim();
    model = model.replace(/^models\//, "");
    if (!model || model.includes("2.5-flash")) {
      model = "gemini-4-argon";
    }
    return model;
  }
  isConfigured(settings) {
    if (settings.localBackend?.enabled && settings.localBackend.baseUrl) {
      return true;
    }
    return !!settings.geminiApiKey && settings.geminiApiKey.trim().length > 0;
  }
  async listModels(settings) {
    if (!this.isConfigured(settings)) {
      return _GeminiProvider.DEFAULT_MODELS;
    }
    try {
      const apiKey = settings.geminiApiKey.trim();
      const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(apiKey)}`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8e3);
      const resp = await fetch(url, { signal: controller.signal });
      clearTimeout(timeoutId);
      if (!resp.ok) {
        return _GeminiProvider.DEFAULT_MODELS;
      }
      const data = await resp.json();
      if (Array.isArray(data.models)) {
        const models = data.models.filter((m) => m.supportedGenerationMethods && m.supportedGenerationMethods.includes("generateContent")).map((m) => {
          const shortId = m.name.replace(/^models\//, "");
          return {
            id: shortId,
            name: m.displayName || shortId,
            description: m.description,
            isFrontierReasoning: shortId.includes("argon") || shortId.includes("pro")
          };
        }).filter((m) => !m.id.includes("2.5-flash"));
        if (!models.some((m) => m.id === "gemini-4-argon")) {
          models.unshift({
            id: "gemini-4-argon",
            name: "Gemini 4 Argon (Latest Frontier Reasoning & Coding)",
            isDefault: true,
            isFrontierReasoning: true
          });
        }
        if (models.length > 0) {
          return models;
        }
      }
    } catch {
    }
    return _GeminiProvider.DEFAULT_MODELS;
  }
  async testConnection(settings) {
    if (!this.isConfigured(settings)) {
      return {
        success: false,
        message: "Google Gemini API key is not configured."
      };
    }
    if (settings.localBackend?.enabled && settings.localBackend.baseUrl) {
      try {
        const resp = await fetch(`${settings.localBackend.baseUrl.replace(/\/+$/, "")}/api/test`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            provider: "gemini",
            model: this.resolveModel(settings),
            apiKeyOverride: settings.geminiApiKey || void 0
          })
        });
        const result = await resp.json();
        return result;
      } catch (e) {
        return {
          success: false,
          message: `Local backend proxy unreachable at ${settings.localBackend.baseUrl}: ${e.message}`
        };
      }
    }
    const startTime = Date.now();
    try {
      const apiKey = settings.geminiApiKey.trim();
      const cleanModel = this.resolveModel(settings);
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${cleanModel}:generateContent?key=${encodeURIComponent(apiKey)}`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 12e3);
      const resp = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: 'Respond with: {"status": "ok"}' }] }],
          generationConfig: {
            temperature: 0.1,
            maxOutputTokens: 50,
            responseMimeType: "application/json"
          }
        }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startTime;
      if (!resp.ok) {
        const errorText = await resp.text();
        let message = `API request failed with status ${resp.status}`;
        try {
          const errJson = JSON.parse(errorText);
          if (errJson.error?.message) {
            message = errJson.error.message;
          }
        } catch {
        }
        if (resp.status === 404) {
          message = `Model "${cleanModel}" is not available on this Google account or project. Switch to Gemini 3.8 Flash or check your API key permissions.`;
        } else if (resp.status === 400 || resp.status === 403) {
          message = `Authentication Failed (${resp.status}): Check your Gemini API key. Details: ${message}`;
        } else if (resp.status === 429) {
          message = `Quota / Rate limit reached (HTTP 429). Please wait a moment.`;
        }
        return { success: false, message, latencyMs, testedModel: cleanModel };
      }
      const availableModels = (await this.listModels(settings)).map((m) => m.id);
      return {
        success: true,
        message: `Successfully connected to Gemini (${cleanModel}) in ${latencyMs}ms!`,
        availableModels,
        latencyMs,
        testedModel: cleanModel
      };
    } catch (e) {
      const latencyMs = Date.now() - startTime;
      if (e.name === "AbortError") {
        return { success: false, message: "Connection test timed out after 12s", latencyMs };
      }
      return { success: false, message: `Connection error: ${e.message}`, latencyMs };
    }
  }
  async generate(req, settings) {
    if (!this.isConfigured(settings)) {
      throw new Error("Google Gemini API key is missing. Please set your API key in extension settings or enable the Local Backend Proxy.");
    }
    const model = this.resolveModel(settings);
    if (settings.localBackend?.enabled && settings.localBackend.baseUrl) {
      const resp = await fetch(`${settings.localBackend.baseUrl.replace(/\/+$/, "")}/api/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider: "gemini",
          model,
          request: req,
          apiKeyOverride: settings.geminiApiKey || void 0
        })
      });
      const json = await resp.json();
      if (!resp.ok || !json.success) {
        throw new Error(json.error || `Local backend error (status ${resp.status})`);
      }
      return json.data;
    }
    const apiKey = settings.geminiApiKey.trim();
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(apiKey)}`;
    const { systemInstruction, userPrompt } = PromptBuilder.buildPrompt(req);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 45e3);
    try {
      const resp = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: systemInstruction }]
          },
          contents: [
            {
              role: "user",
              parts: [{ text: userPrompt }]
            }
          ],
          generationConfig: {
            temperature: 0.2,
            responseMimeType: "application/json"
          }
        }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!resp.ok) {
        const errorText = await resp.text();
        let errorMsg = `Gemini API returned status ${resp.status}`;
        try {
          const parsed = JSON.parse(errorText);
          if (parsed.error?.message) {
            errorMsg = parsed.error.message;
          }
        } catch {
        }
        if (resp.status === 404) {
          throw new Error(`Model "${model}" was not found or is unavailable to your Google AI account. Try selecting "Gemini 3.8 Flash" or enter another model in Settings. (${errorMsg})`);
        } else if (resp.status === 429) {
          throw new Error(`Gemini rate limit exceeded. Please wait a minute and retry. (${errorMsg})`);
        } else if (resp.status === 400 || resp.status === 403) {
          throw new Error(`Gemini authorization error: ${errorMsg}`);
        }
        throw new Error(errorMsg);
      }
      const data = await resp.json();
      const candidateText = data.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!candidateText) {
        throw new Error("Gemini did not return any candidates or response text");
      }
      const validation = ResponseValidator.validate(candidateText, req.targetLanguage);
      if (!validation.isValid || !validation.sanitizedResponse) {
        throw new Error(`Failed to validate AI output: ${validation.errors.join("; ")}`);
      }
      return validation.sanitizedResponse;
    } catch (err) {
      clearTimeout(timeoutId);
      if (err.name === "AbortError") {
        throw new Error("Gemini generation request timed out after 45 seconds. Please check your connection and try again.");
      }
      throw err;
    }
  }
};

// src/providers/openai-provider.ts
var OpenAIProvider = class _OpenAIProvider {
  id = "openai";
  name = "OpenAI";
  static DEFAULT_MODELS = [
    { id: "gpt-6-astra", name: "GPT-6 Astra (Latest Frontier Coding & Intelligence)", isDefault: true, isFrontierReasoning: true },
    { id: "gpt-6.1-sol", name: "GPT-6.1 Sol (Next-Gen Deep Reasoning)", isFrontierReasoning: true },
    { id: "gpt-4o", name: "GPT-4o (High Intelligence)" },
    { id: "gpt-4o-mini", name: "GPT-4o Mini (Fast & Efficient)" },
    { id: "o3-mini", name: "o3-mini (Advanced Reasoning)", isFrontierReasoning: true }
  ];
  resolveModel(settings) {
    return settings.openaiCustomModel?.trim() || settings.selectedModel?.trim() || settings.openaiModel?.trim() || "gpt-6-astra";
  }
  isConfigured(settings) {
    if (settings.localBackend?.enabled && settings.localBackend.baseUrl) {
      return true;
    }
    return !!settings.openaiApiKey && settings.openaiApiKey.trim().length > 0;
  }
  getBaseUrl(settings) {
    return (settings.openaiBaseUrl || "https://api.openai.com/v1").replace(/\/+$/, "");
  }
  async listModels(settings) {
    if (!this.isConfigured(settings)) {
      return _OpenAIProvider.DEFAULT_MODELS;
    }
    try {
      const apiKey = settings.openaiApiKey.trim();
      const baseUrl = this.getBaseUrl(settings);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8e3);
      const resp = await fetch(`${baseUrl}/models`, {
        headers: {
          Authorization: `Bearer ${apiKey}`
        },
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!resp.ok) {
        return _OpenAIProvider.DEFAULT_MODELS;
      }
      const data = await resp.json();
      if (Array.isArray(data.data)) {
        const relevantModels = data.data.filter((m) => {
          const id = m.id.toLowerCase();
          return id.includes("gpt") || id.includes("o1") || id.includes("o3") || id.includes("astra") || id.includes("sol");
        }).map((m) => ({
          id: m.id,
          name: m.id,
          isFrontierReasoning: m.id.includes("6") || m.id.includes("o1") || m.id.includes("o3")
        })).sort((a, b) => a.id.localeCompare(b.id));
        if (!relevantModels.some((m) => m.id === "gpt-6-astra")) {
          relevantModels.unshift({
            id: "gpt-6-astra",
            name: "GPT-6 Astra (Latest Frontier Coding & Intelligence)",
            isDefault: true,
            isFrontierReasoning: true
          });
        }
        if (!relevantModels.some((m) => m.id === "gpt-6.1-sol")) {
          relevantModels.splice(1, 0, {
            id: "gpt-6.1-sol",
            name: "GPT-6.1 Sol (Next-Gen Deep Reasoning)",
            isFrontierReasoning: true
          });
        }
        if (relevantModels.length > 0) {
          return relevantModels;
        }
      }
    } catch {
    }
    return _OpenAIProvider.DEFAULT_MODELS;
  }
  async testConnection(settings) {
    if (!this.isConfigured(settings)) {
      return {
        success: false,
        message: "OpenAI API key is not configured."
      };
    }
    if (settings.localBackend?.enabled && settings.localBackend.baseUrl) {
      try {
        const resp = await fetch(`${settings.localBackend.baseUrl.replace(/\/+$/, "")}/api/test`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            provider: "openai",
            model: this.resolveModel(settings),
            apiKeyOverride: settings.openaiApiKey || void 0
          })
        });
        const result = await resp.json();
        return result;
      } catch (e) {
        return {
          success: false,
          message: `Local backend proxy unreachable at ${settings.localBackend.baseUrl}: ${e.message}`
        };
      }
    }
    const startTime = Date.now();
    try {
      const apiKey = settings.openaiApiKey.trim();
      const baseUrl = this.getBaseUrl(settings);
      const model = this.resolveModel(settings);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 12e3);
      const resp = await fetch(`${baseUrl}/models`, {
        headers: {
          Authorization: `Bearer ${apiKey}`
        },
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startTime;
      if (!resp.ok) {
        const errorText = await resp.text();
        let message = `API request failed with status ${resp.status}`;
        try {
          const errJson = JSON.parse(errorText);
          if (errJson.error?.message) {
            message = errJson.error.message;
          }
        } catch {
        }
        if (resp.status === 401) {
          message = "Authentication Failed: Invalid OpenAI API key.";
        } else if (resp.status === 429) {
          message = "Quota or rate limit reached (HTTP 429). Please check your OpenAI billing/credits.";
        }
        return { success: false, message, latencyMs, testedModel: model };
      }
      const availableModels = (await this.listModels(settings)).map((m) => m.id);
      return {
        success: true,
        message: `Connected to OpenAI (${model}) successfully in ${latencyMs}ms!`,
        availableModels,
        latencyMs,
        testedModel: model
      };
    } catch (e) {
      const latencyMs = Date.now() - startTime;
      if (e.name === "AbortError") {
        return { success: false, message: "Connection test timed out after 12s", latencyMs };
      }
      return { success: false, message: `Connection error: ${e.message}`, latencyMs };
    }
  }
  async generate(req, settings) {
    if (!this.isConfigured(settings)) {
      throw new Error("OpenAI API key is missing. Please set your API key in extension settings or enable Local Backend Proxy.");
    }
    const model = this.resolveModel(settings);
    if (settings.localBackend?.enabled && settings.localBackend.baseUrl) {
      const resp = await fetch(`${settings.localBackend.baseUrl.replace(/\/+$/, "")}/api/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          provider: "openai",
          model,
          request: req,
          apiKeyOverride: settings.openaiApiKey || void 0
        })
      });
      const json = await resp.json();
      if (!resp.ok || !json.success) {
        throw new Error(json.error || `Local backend error (status ${resp.status})`);
      }
      return json.data;
    }
    const apiKey = settings.openaiApiKey.trim();
    const baseUrl = this.getBaseUrl(settings);
    const { systemInstruction, userPrompt } = PromptBuilder.buildPrompt(req);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 45e3);
    const isReasoningModel = model.startsWith("o1") || model.startsWith("o3") || model.includes("sol");
    const bodyPayload = {
      model,
      messages: [
        { role: "system", content: systemInstruction },
        { role: "user", content: userPrompt }
      ]
    };
    if (!isReasoningModel) {
      bodyPayload.temperature = 0.2;
      bodyPayload.response_format = { type: "json_object" };
    }
    try {
      const resp = await fetch(`${baseUrl}/chat/completions`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify(bodyPayload),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!resp.ok) {
        const errorText = await resp.text();
        let errorMsg = `OpenAI API returned status ${resp.status}`;
        try {
          const parsed = JSON.parse(errorText);
          if (parsed.error?.message) {
            errorMsg = parsed.error.message;
          }
        } catch {
        }
        if (resp.status === 404) {
          throw new Error(`Model "${model}" does not exist or your OpenAI account tier does not have access to it. Try selecting "GPT-4o Mini" or verify model access in Settings. (${errorMsg})`);
        } else if (resp.status === 429) {
          throw new Error(`OpenAI rate limit or quota exceeded: ${errorMsg}`);
        } else if (resp.status === 401) {
          throw new Error(`OpenAI authentication failed: ${errorMsg}`);
        }
        throw new Error(errorMsg);
      }
      const data = await resp.json();
      const content = data.choices?.[0]?.message?.content;
      if (!content) {
        throw new Error("OpenAI returned an empty response choice");
      }
      const validation = ResponseValidator.validate(content, req.targetLanguage);
      if (!validation.isValid || !validation.sanitizedResponse) {
        throw new Error(`Failed to validate AI output: ${validation.errors.join("; ")}`);
      }
      return validation.sanitizedResponse;
    } catch (err) {
      clearTimeout(timeoutId);
      if (err.name === "AbortError") {
        throw new Error("OpenAI generation request timed out after 45 seconds.");
      }
      throw err;
    }
  }
};

// src/providers/codemind-provider.ts
var CodeMindProvider = class _CodeMindProvider {
  id = "codemind";
  name = "CodeMind AI";
  static DEFAULT_MODELS = [
    {
      id: "codemind-ai",
      name: "CodeMind AI (Local / Custom Checkpoint)",
      description: "Your local fine-tuned or customized coding model alias in Ollama",
      isDefault: true,
      isLocal: true,
      isCustomTrained: true
    },
    {
      id: "qwen2.5-coder:7b",
      name: "Qwen 2.5 Coder 7B",
      description: "Top-tier code reasoning optimized for 8GB M2 Macs (~4.7GB RAM)",
      isLocal: true
    },
    {
      id: "qwen2.5-coder:1.5b",
      name: "Qwen 2.5 Coder 1.5B",
      description: "Ultra-lightweight and fast local coding model (~1.3GB RAM)",
      isLocal: true
    },
    {
      id: "deepseek-coder:6.7b",
      name: "DeepSeek Coder 6.7B",
      description: "Specialized Python & C++ algorithmic reasoning (~4.5GB RAM)",
      isLocal: true
    },
    {
      id: "codellama:7b",
      name: "CodeLlama 7B",
      description: "Meta CodeLlama 7B parameter base model",
      isLocal: true
    }
  ];
  isConfigured(settings) {
    return settings.codemindEnabled !== false && !!settings.codemindEndpoint && settings.codemindEndpoint.trim().length > 0;
  }
  getEndpoint(settings) {
    return (settings.codemindEndpoint || "http://127.0.0.1:11434").replace(/\/+$/, "");
  }
  getModel(settings) {
    if (settings.codemindCustomModel?.trim()) {
      return settings.codemindCustomModel.trim();
    }
    if (settings.selectedProvider === "codemind" && settings.selectedModel?.trim()) {
      return settings.selectedModel.trim();
    }
    return settings.codemindModel || "codemind-ai";
  }
  /**
   * Dynamically query Ollama's local catalog (/api/tags) to list installed models
   */
  async listModels(settings) {
    if (!this.isConfigured(settings)) {
      return _CodeMindProvider.DEFAULT_MODELS;
    }
    try {
      const endpoint = this.getEndpoint(settings);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4e3);
      const resp = await fetch(`${endpoint}/api/tags`, {
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (resp.ok) {
        const data = await resp.json();
        if (Array.isArray(data.models) && data.models.length > 0) {
          const installedNames = new Set(data.models.map((m) => m.name || m.model));
          const dynamicList = data.models.map((m) => {
            const modelName = m.name || m.model;
            const isCodeMindAlias = modelName.toLowerCase().includes("codemind");
            return {
              id: modelName,
              name: isCodeMindAlias ? `CodeMind AI (${modelName})` : `${modelName} (Installed Locally)`,
              description: `Size: ${(m.size / (1024 * 1024 * 1024)).toFixed(1)} GB \xB7 Family: ${m.details?.family || "local"}`,
              isLocal: true,
              isCustomTrained: isCodeMindAlias
            };
          });
          const activeModel = this.getModel(settings);
          if (!installedNames.has(activeModel)) {
            dynamicList.unshift({
              id: activeModel,
              name: `${activeModel} (Configured Target)`,
              description: "Model identifier specified in extension settings",
              isDefault: true,
              isLocal: true,
              isCustomTrained: activeModel.toLowerCase().includes("codemind")
            });
          }
          return dynamicList;
        }
      }
    } catch {
    }
    return _CodeMindProvider.DEFAULT_MODELS;
  }
  /**
   * Test connection to local Ollama runtime and verify active model status
   */
  async testConnection(settings) {
    if (!this.isConfigured(settings)) {
      return {
        success: false,
        message: "CodeMind AI is disabled or local endpoint is empty (default: http://127.0.0.1:11434)"
      };
    }
    const endpoint = this.getEndpoint(settings);
    const targetModel = this.getModel(settings);
    const startTime = Date.now();
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6e3);
      const resp = await fetch(`${endpoint}/api/tags`, {
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startTime;
      if (!resp.ok) {
        return {
          success: false,
          message: `Local endpoint responded with HTTP ${resp.status}`,
          latencyMs
        };
      }
      const data = await resp.json();
      const installedModels = Array.isArray(data.models) ? data.models.map((m) => m.name || m.model) : [];
      const hasTargetModel = installedModels.some(
        (name) => name === targetModel || name.startsWith(`${targetModel}:`)
      );
      if (hasTargetModel) {
        return {
          success: true,
          message: `Online! CodeMind AI connected to Ollama (${latencyMs}ms). Model "${targetModel}" is installed and ready.`,
          testedModel: targetModel,
          availableModels: installedModels,
          isLocalOllama: true,
          latencyMs
        };
      }
      return {
        success: true,
        message: `Ollama is running (${latencyMs}ms), but model "${targetModel}" was not found in local models: [${installedModels.join(", ") || "none"}].`,
        instructionHint: `Run in your Mac Terminal:
  ollama run qwen2.5-coder:7b
or create the CodeMind alias:
  ollama cp qwen2.5-coder:7b ${targetModel}`,
        testedModel: targetModel,
        availableModels: installedModels,
        isLocalOllama: true,
        latencyMs
      };
    } catch (e) {
      const latencyMs = Date.now() - startTime;
      const isConnectionRefused = e.name === "AbortError" || e.message?.includes("Failed to fetch") || e.message?.includes("NetworkError") || e.message?.includes("ECONNREFUSED");
      if (isConnectionRefused) {
        return {
          success: false,
          message: `Could not reach local Ollama service at ${endpoint}.`,
          instructionHint: `To start your local model on macOS:
1. Install: brew install ollama
2. Start server: ollama serve
3. Run model: ollama run qwen2.5-coder:7b`,
          isLocalOllama: false,
          latencyMs
        };
      }
      return {
        success: false,
        message: `Connection test error: ${e.message}`,
        latencyMs
      };
    }
  }
  /**
   * Generate LeetCode solution using local Ollama model with structured output
   */
  async generate(req, settings) {
    if (!this.isConfigured(settings)) {
      throw new Error(
        "CodeMind AI is not enabled or endpoint is missing. Please enable it in Settings."
      );
    }
    const endpoint = this.getEndpoint(settings);
    const model = this.getModel(settings);
    const timeoutSec = settings.codemindTimeoutSeconds || 60;
    const maxTokens = settings.codemindMaxTokens || 4096;
    const temperature = settings.codemindTemperature ?? 0.2;
    const { systemInstruction, userPrompt } = PromptBuilder.buildPrompt(req);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutSec * 1e3);
    try {
      const resp = await fetch(`${endpoint}/api/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: systemInstruction },
            { role: "user", content: userPrompt }
          ],
          format: "json",
          stream: false,
          options: {
            temperature,
            num_predict: maxTokens
          }
        }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!resp.ok) {
        if (resp.status === 404) {
          throw new Error(
            `Model "${model}" was not found in your local Ollama library. Run "ollama pull qwen2.5-coder:7b" or check the model tag in Settings.`
          );
        }
        const errorText = await resp.text();
        throw new Error(`CodeMind AI local endpoint returned HTTP ${resp.status}: ${errorText.substring(0, 200)}`);
      }
      const data = await resp.json();
      const content = data.message?.content;
      if (!content || !content.trim()) {
        throw new Error("CodeMind AI returned an empty response. Verify model context length and prompt.");
      }
      const validation = ResponseValidator.validate(content, req.targetLanguage);
      if (!validation.isValid || !validation.sanitizedResponse) {
        throw new Error(`Failed to parse CodeMind AI output: ${validation.errors.join("; ")}`);
      }
      return validation.sanitizedResponse;
    } catch (err) {
      clearTimeout(timeoutId);
      if (err.name === "AbortError") {
        throw new Error(
          `CodeMind AI generation timed out after ${timeoutSec}s. For faster execution on 8GB M2 Mac, try "qwen2.5-coder:7b" or "qwen2.5-coder:1.5b", or increase timeout in Settings.`
        );
      }
      if (err.message?.includes("Failed to fetch") || err.message?.includes("NetworkError") || err.message?.includes("ECONNREFUSED")) {
        throw new Error(
          `Cannot reach CodeMind AI at ${endpoint}. Please ensure Ollama is running: execute "ollama serve" in Terminal.`
        );
      }
      throw err;
    }
  }
};

// src/providers/custom-provider.ts
var CustomProvider = class _CustomProvider {
  id = "custom";
  name = "Custom / OpenAI Compatible";
  static DEFAULT_MODELS = [
    { id: "llama-3.3-70b-versatile", name: "Llama 3.3 70B", isDefault: true },
    { id: "deepseek-chat", name: "DeepSeek Chat" },
    { id: "qwen-2.5-coder-32b", name: "Qwen 2.5 Coder 32B" },
    { id: "mistral-large-latest", name: "Mistral Large" }
  ];
  isConfigured(settings) {
    return !!settings.customBaseUrl && settings.customBaseUrl.trim().length > 0;
  }
  getBaseUrl(settings) {
    return (settings.customBaseUrl || "http://localhost:11434/v1").replace(/\/+$/, "");
  }
  async listModels(settings) {
    if (!this.isConfigured(settings)) {
      return _CustomProvider.DEFAULT_MODELS;
    }
    try {
      const baseUrl = this.getBaseUrl(settings);
      const headers = {};
      if (settings.customApiKey?.trim()) {
        headers["Authorization"] = `Bearer ${settings.customApiKey.trim()}`;
      }
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 6e3);
      const resp = await fetch(`${baseUrl}/models`, {
        headers,
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (resp.ok) {
        const data = await resp.json();
        const list = Array.isArray(data.data) ? data.data : Array.isArray(data.models) ? data.models : [];
        if (list.length > 0) {
          return list.map((m) => ({
            id: m.id || m.name,
            name: m.id || m.name
          }));
        }
      }
    } catch {
    }
    return _CustomProvider.DEFAULT_MODELS;
  }
  async testConnection(settings) {
    if (!this.isConfigured(settings)) {
      return {
        success: false,
        message: "Custom base URL is not configured (e.g. http://localhost:11434/v1)"
      };
    }
    const startTime = Date.now();
    try {
      const baseUrl = this.getBaseUrl(settings);
      const headers = {};
      if (settings.customApiKey?.trim()) {
        headers["Authorization"] = `Bearer ${settings.customApiKey.trim()}`;
      }
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8e3);
      const resp = await fetch(`${baseUrl}/models`, {
        headers,
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      const latencyMs = Date.now() - startTime;
      if (!resp.ok) {
        return {
          success: false,
          message: `Custom endpoint responded with status ${resp.status}`,
          latencyMs
        };
      }
      const models = await this.listModels(settings);
      return {
        success: true,
        message: `Successfully connected to endpoint! Found ${models.length} model(s).`,
        availableModels: models.map((m) => m.id),
        latencyMs
      };
    } catch (e) {
      const latencyMs = Date.now() - startTime;
      return {
        success: false,
        message: `Cannot reach custom endpoint: ${e.message}`,
        latencyMs
      };
    }
  }
  async generate(req, settings) {
    if (!this.isConfigured(settings)) {
      throw new Error("Custom endpoint Base URL is missing in extension settings.");
    }
    const baseUrl = this.getBaseUrl(settings);
    const model = settings.customModel || "llama-3.3-70b-versatile";
    const { systemInstruction, userPrompt } = PromptBuilder.buildPrompt(req);
    const headers = {
      "Content-Type": "application/json"
    };
    if (settings.customApiKey?.trim()) {
      headers["Authorization"] = `Bearer ${settings.customApiKey.trim()}`;
    }
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5e4);
    try {
      const resp = await fetch(`${baseUrl}/chat/completions`, {
        method: "POST",
        headers,
        body: JSON.stringify({
          model,
          messages: [
            { role: "system", content: systemInstruction },
            { role: "user", content: userPrompt }
          ],
          temperature: 0.2
        }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!resp.ok) {
        const errorText = await resp.text();
        throw new Error(`Custom endpoint error (status ${resp.status}): ${errorText.substring(0, 200)}`);
      }
      const data = await resp.json();
      const content = data.choices?.[0]?.message?.content;
      if (!content) {
        throw new Error("Custom endpoint returned empty content");
      }
      const validation = ResponseValidator.validate(content, req.targetLanguage);
      if (!validation.isValid || !validation.sanitizedResponse) {
        throw new Error(`Failed to validate AI output: ${validation.errors.join("; ")}`);
      }
      return validation.sanitizedResponse;
    } catch (err) {
      clearTimeout(timeoutId);
      if (err.name === "AbortError") {
        throw new Error("Custom provider request timed out after 50 seconds.");
      }
      throw err;
    }
  }
};

// src/providers/provider-factory.ts
var ProviderFactory = class {
  static providers = /* @__PURE__ */ new Map([
    ["codemind", new CodeMindProvider()],
    ["gemini", new GeminiProvider()],
    ["openai", new OpenAIProvider()],
    ["custom", new CustomProvider()]
  ]);
  static getProvider(type) {
    const provider = this.providers.get(type);
    if (!provider) {
      throw new Error(`Unsupported AI Provider: ${type}`);
    }
    return provider;
  }
  static getAllProviders() {
    return Array.from(this.providers.values());
  }
};

// src/storage/extension-storage.ts
var DEFAULT_SETTINGS = {
  selectedProvider: "gemini",
  selectedModel: "gemini-4-argon",
  targetLanguage: "python3",
  useEditorLanguage: true,
  confirmBeforeOverwrite: true,
  autoAnalyzeOnOpen: false,
  debugMode: false,
  localBackend: {
    enabled: false,
    baseUrl: "http://localhost:3001"
  },
  safeguards: {
    enabled: true,
    maxRequestsPerDay: 50,
    warnBeforeReasoningModels: true
  },
  usageRecords: [],
  connectionStatus: {},
  // CodeMind AI Default Configuration (Local Ollama on MacBook Air M2)
  codemindEnabled: true,
  codemindEndpoint: "http://127.0.0.1:11434",
  codemindModel: "codemind-ai",
  codemindCustomModel: "",
  codemindTimeoutSeconds: 60,
  codemindMaxTokens: 4096,
  codemindTemperature: 0.2,
  geminiApiKey: "",
  geminiModel: "gemini-4-argon",
  geminiCustomModel: "",
  openaiApiKey: "",
  openaiModel: "gpt-6-astra",
  openaiBaseUrl: "https://api.openai.com/v1",
  openaiCustomModel: "",
  customApiKey: "",
  customModel: "llama-3.3-70b-versatile",
  customBaseUrl: "http://localhost:11434/v1"
};
var SETTINGS_KEY = "leetcode_copilot_settings";
var PROBLEMS_KEY = "leetcode_copilot_imported_problems";
var SOLUTION_CACHE_KEY_PREFIX = "leetcode_copilot_solution_";
var ExtensionStorage = class {
  static isChromeStorageAvailable() {
    return typeof chrome !== "undefined" && !!chrome.storage && !!chrome.storage.local;
  }
  static async getSettings() {
    if (this.isChromeStorageAvailable()) {
      return new Promise((resolve) => {
        chrome.storage.local.get([SETTINGS_KEY], (result) => {
          if (chrome.runtime.lastError) {
            console.error("Error reading storage:", chrome.runtime.lastError);
            resolve(DEFAULT_SETTINGS);
            return;
          }
          const stored = result[SETTINGS_KEY];
          const merged = {
            ...DEFAULT_SETTINGS,
            ...stored || {}
          };
          if (merged.selectedModel?.includes("2.5-flash")) {
            merged.selectedModel = "gemini-4-argon";
          }
          if (merged.geminiModel?.includes("2.5-flash")) {
            merged.geminiModel = "gemini-4-argon";
          }
          resolve(merged);
        });
      });
    }
    try {
      const stored = localStorage.getItem(SETTINGS_KEY);
      if (stored) {
        const merged = { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
        if (merged.selectedModel?.includes("2.5-flash")) {
          merged.selectedModel = "gemini-4-argon";
        }
        if (merged.geminiModel?.includes("2.5-flash")) {
          merged.geminiModel = "gemini-4-argon";
        }
        return merged;
      }
      return DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  }
  static async saveSettings(partial) {
    const current = await this.getSettings();
    const updated = { ...current, ...partial };
    if (this.isChromeStorageAvailable()) {
      return new Promise((resolve) => {
        chrome.storage.local.set({ [SETTINGS_KEY]: updated }, () => {
          resolve(updated);
        });
      });
    }
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
    } catch (e) {
      console.warn("LocalStorage save failed:", e);
    }
    return updated;
  }
  static async recordUsage(record) {
    const settings = await this.getSettings();
    const records = [record, ...settings.usageRecords || []].slice(0, 100);
    await this.saveSettings({ usageRecords: records });
  }
  static async checkDailySpendingSafeguard() {
    const settings = await this.getSettings();
    const safeguards = settings.safeguards || DEFAULT_SETTINGS.safeguards;
    if (!safeguards.enabled) {
      return { allowed: true, count: 0, max: 0 };
    }
    const oneDayAgo = Date.now() - 24 * 60 * 60 * 1e3;
    const dailyRequests = (settings.usageRecords || []).filter(
      (r) => r.timestamp > oneDayAgo && r.success
    );
    const count = dailyRequests.length;
    const max = safeguards.maxRequestsPerDay || 50;
    if (count >= max) {
      return {
        allowed: false,
        reason: `Daily spending safeguard reached: ${count}/${max} requests in the last 24h. You can increase or toggle this limit in Settings.`,
        count,
        max
      };
    }
    return { allowed: true, count, max };
  }
  static async setConnectionStatus(provider, status) {
    const settings = await this.getSettings();
    const updatedStatus = {
      ...settings.connectionStatus || {},
      [provider]: status
    };
    await this.saveSettings({ connectionStatus: updatedStatus });
  }
  static async getImportedProblems() {
    if (this.isChromeStorageAvailable()) {
      return new Promise((resolve) => {
        chrome.storage.local.get([PROBLEMS_KEY], (result) => {
          resolve(result[PROBLEMS_KEY] || []);
        });
      });
    }
    try {
      const stored = localStorage.getItem(PROBLEMS_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }
  static async saveImportedProblems(problems) {
    if (this.isChromeStorageAvailable()) {
      return new Promise((resolve) => {
        chrome.storage.local.set({ [PROBLEMS_KEY]: problems }, () => resolve());
      });
    }
    try {
      localStorage.setItem(PROBLEMS_KEY, JSON.stringify(problems));
    } catch (e) {
      console.warn("LocalStorage save failed:", e);
    }
  }
  static async getCachedSolution(slug) {
    const key = `${SOLUTION_CACHE_KEY_PREFIX}${slug}`;
    if (this.isChromeStorageAvailable()) {
      return new Promise((resolve) => {
        chrome.storage.local.get([key], (result) => {
          resolve(result[key] || null);
        });
      });
    }
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch {
      return null;
    }
  }
  static async cacheSolution(slug, solution) {
    const key = `${SOLUTION_CACHE_KEY_PREFIX}${slug}`;
    if (this.isChromeStorageAvailable()) {
      return new Promise((resolve) => {
        chrome.storage.local.set({ [key]: solution }, () => resolve());
      });
    }
    try {
      localStorage.setItem(key, JSON.stringify(solution));
    } catch (e) {
      console.warn("LocalStorage save failed:", e);
    }
  }
};

// src/solver/solution-generator.ts
var SolutionGenerator = class {
  static async generateSolution(request, settings) {
    const safeguardCheck = await ExtensionStorage.checkDailySpendingSafeguard();
    if (!safeguardCheck.allowed) {
      throw new Error(safeguardCheck.reason || "Daily spending safeguard reached.");
    }
    const provider = ProviderFactory.getProvider(settings.selectedProvider);
    if (!provider.isConfigured(settings)) {
      throw new Error(`Provider "${provider.name}" is not configured. Please add your API key in extension settings or enable the Local Backend Proxy.`);
    }
    let lastError = null;
    const maxRetries = 2;
    const startTime = Date.now();
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const solution = await provider.generate(request, settings);
        const latencyMs = Date.now() - startTime;
        await ExtensionStorage.recordUsage({
          id: `req_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
          timestamp: Date.now(),
          provider: settings.selectedProvider,
          model: settings.selectedModel,
          tokensEstimated: Math.round((request.problem.statement.length + solution.code.length) / 4),
          success: true,
          latencyMs,
          action: request.action
        });
        if (request.problem.slug) {
          await ExtensionStorage.cacheSolution(request.problem.slug, solution);
        }
        return solution;
      } catch (err) {
        lastError = err;
        const msg = String(err.message || "").toLowerCase();
        if (msg.includes("auth") || msg.includes("api key") || msg.includes("quota") || msg.includes("401") || msg.includes("403") || msg.includes("404") || msg.includes("not found") || msg.includes("does not exist")) {
          await ExtensionStorage.recordUsage({
            id: `err_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
            timestamp: Date.now(),
            provider: settings.selectedProvider,
            model: settings.selectedModel,
            tokensEstimated: 0,
            success: false,
            latencyMs: Date.now() - startTime,
            action: request.action,
            error: err.message
          });
          throw err;
        }
        if (attempt < maxRetries) {
          await new Promise((r) => setTimeout(r, 1200 * attempt));
        }
      }
    }
    await ExtensionStorage.recordUsage({
      id: `err_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: Date.now(),
      provider: settings.selectedProvider,
      model: settings.selectedModel,
      tokensEstimated: 0,
      success: false,
      latencyMs: Date.now() - startTime,
      action: request.action,
      error: lastError?.message || "Failed after retries"
    });
    throw lastError || new Error("Failed to generate solution after multiple attempts");
  }
};

// src/background/service-worker.ts
console.log("[LeetCode AI Copilot] Background Service Worker initialized");
chrome.runtime.onInstalled.addListener((details) => {
  console.log("[LeetCode AI Copilot] Extension installed/updated:", details.reason);
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    try {
      switch (message.type) {
        case "PING": {
          sendResponse({ success: true, data: { status: "service-worker-alive" } });
          break;
        }
        case "GENERATE_SOLUTION": {
          const { request, settings } = message.payload;
          const solution = await SolutionGenerator.generateSolution(request, settings);
          sendResponse({
            success: true,
            data: solution
          });
          break;
        }
        case "TEST_PROVIDER_CONNECTION": {
          const { provider, settings } = message.payload;
          const providerInstance = ProviderFactory.getProvider(provider);
          const result = await providerInstance.testConnection(settings);
          sendResponse({
            success: result.success,
            data: result,
            error: result.success ? void 0 : result.message
          });
          break;
        }
        case "LIST_MODELS": {
          const { provider, settings } = message.payload;
          const providerInstance = ProviderFactory.getProvider(provider);
          const models = await providerInstance.listModels(settings);
          sendResponse({
            success: true,
            data: models
          });
          break;
        }
        default:
          sendResponse({ success: false, error: "Unhandled background message type" });
      }
    } catch (err) {
      console.error("[LeetCode AI Copilot] Error handling message in service worker:", err);
      sendResponse({
        success: false,
        error: err.message || "Unknown background service worker error"
      });
    }
  })();
  return true;
});
