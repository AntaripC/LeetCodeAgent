"use strict";
(() => {
  // src/solver/language-registry.ts
  var SUPPORTED_LANGUAGES = [
    {
      id: "python3",
      displayName: "Python 3",
      monacoLanguageId: "python",
      aliases: ["python3", "python", "py"],
      fileExtension: ".py",
      commentPrefix: "#",
      typicalBoilerplate: "class Solution:\n    def solve(self) -> None:\n        pass\n",
      standardImports: ["from typing import List, Optional, Dict, Set, Tuple", "import collections", "import heapq"]
    },
    {
      id: "cpp",
      displayName: "C++",
      monacoLanguageId: "cpp",
      aliases: ["cpp", "c++", "g++"],
      fileExtension: ".cpp",
      commentPrefix: "//",
      typicalBoilerplate: "class Solution {\npublic:\n    void solve() {\n        \n    }\n};",
      standardImports: ["#include <vector>", "#include <string>", "#include <unordered_map>", "#include <algorithm>", "using namespace std;"]
    },
    {
      id: "java",
      displayName: "Java",
      monacoLanguageId: "java",
      aliases: ["java"],
      fileExtension: ".java",
      commentPrefix: "//",
      typicalBoilerplate: "class Solution {\n    public void solve() {\n        \n    }\n}",
      standardImports: ["import java.util.*;"]
    },
    {
      id: "c",
      displayName: "C",
      monacoLanguageId: "c",
      aliases: ["c"],
      fileExtension: ".c",
      commentPrefix: "//",
      typicalBoilerplate: "void solve() {\n    \n}",
      standardImports: ["#include <stdio.h>", "#include <stdlib.h>", "#include <string.h>", "#include <stdbool.h>"]
    },
    {
      id: "csharp",
      displayName: "C#",
      monacoLanguageId: "csharp",
      aliases: ["csharp", "c#", "cs"],
      fileExtension: ".cs",
      commentPrefix: "//",
      typicalBoilerplate: "public class Solution {\n    public void Solve() {\n        \n    }\n}",
      standardImports: ["using System;", "using System.Collections.Generic;"]
    },
    {
      id: "javascript",
      displayName: "JavaScript",
      monacoLanguageId: "javascript",
      aliases: ["javascript", "js"],
      fileExtension: ".js",
      commentPrefix: "//",
      typicalBoilerplate: "/**\n * @return {void}\n */\nvar solve = function() {\n    \n};",
      standardImports: []
    },
    {
      id: "typescript",
      displayName: "TypeScript",
      monacoLanguageId: "typescript",
      aliases: ["typescript", "ts"],
      fileExtension: ".ts",
      commentPrefix: "//",
      typicalBoilerplate: "function solve(): void {\n    \n};",
      standardImports: []
    },
    {
      id: "go",
      displayName: "Go",
      monacoLanguageId: "go",
      aliases: ["go", "golang"],
      fileExtension: ".go",
      commentPrefix: "//",
      typicalBoilerplate: "func solve() {\n    \n}",
      standardImports: ["package main", 'import "fmt"']
    },
    {
      id: "rust",
      displayName: "Rust",
      monacoLanguageId: "rust",
      aliases: ["rust", "rs"],
      fileExtension: ".rs",
      commentPrefix: "//",
      typicalBoilerplate: "impl Solution {\n    pub fn solve() {\n        \n    }\n}",
      standardImports: []
    },
    {
      id: "kotlin",
      displayName: "Kotlin",
      monacoLanguageId: "kotlin",
      aliases: ["kotlin", "kt"],
      fileExtension: ".kt",
      commentPrefix: "//",
      typicalBoilerplate: "class Solution {\n    fun solve() {\n        \n    }\n}",
      standardImports: []
    },
    {
      id: "swift",
      displayName: "Swift",
      monacoLanguageId: "swift",
      aliases: ["swift"],
      fileExtension: ".swift",
      commentPrefix: "//",
      typicalBoilerplate: "class Solution {\n    func solve() {\n        \n    }\n}",
      standardImports: ["import Foundation"]
    },
    {
      id: "php",
      displayName: "PHP",
      monacoLanguageId: "php",
      aliases: ["php"],
      fileExtension: ".php",
      commentPrefix: "//",
      typicalBoilerplate: "class Solution {\n    function solve() {\n        \n    }\n}",
      standardImports: []
    },
    {
      id: "ruby",
      displayName: "Ruby",
      monacoLanguageId: "ruby",
      aliases: ["ruby", "rb"],
      fileExtension: ".rb",
      commentPrefix: "#",
      typicalBoilerplate: "def solve()\n    \nend",
      standardImports: []
    },
    {
      id: "dart",
      displayName: "Dart",
      monacoLanguageId: "dart",
      aliases: ["dart"],
      fileExtension: ".dart",
      commentPrefix: "//",
      typicalBoilerplate: "class Solution {\n    void solve() {\n        \n    }\n}",
      standardImports: []
    },
    {
      id: "scala",
      displayName: "Scala",
      monacoLanguageId: "scala",
      aliases: ["scala"],
      fileExtension: ".scala",
      commentPrefix: "//",
      typicalBoilerplate: "object Solution {\n    def solve(): Unit = {\n        \n    }\n}",
      standardImports: []
    }
  ];
  var LanguageRegistry = class {
    static languageMap = /* @__PURE__ */ new Map();
    static {
      for (const lang of SUPPORTED_LANGUAGES) {
        this.languageMap.set(lang.id.toLowerCase(), lang);
        for (const alias of lang.aliases) {
          this.languageMap.set(alias.toLowerCase(), lang);
        }
      }
    }
    static getAll() {
      return SUPPORTED_LANGUAGES;
    }
    static findByIdOrAlias(identifier) {
      if (!identifier) return void 0;
      const clean = identifier.trim().toLowerCase().replace(/[^a-z0-9#+]/g, "");
      return this.languageMap.get(clean);
    }
    static normalizeLanguageId(identifier) {
      const found = this.findByIdOrAlias(identifier);
      return found ? found.id : "python3";
    }
    static getDisplayName(identifier) {
      const found = this.findByIdOrAlias(identifier);
      return found ? found.displayName : identifier;
    }
    static getMonacoLanguageId(identifier) {
      const found = this.findByIdOrAlias(identifier);
      return found ? found.monacoLanguageId : "plaintext";
    }
    static areLanguagesCompatible(lang1, lang2) {
      const l1 = this.findByIdOrAlias(lang1);
      const l2 = this.findByIdOrAlias(lang2);
      if (!l1 || !l2) return false;
      return l1.id === l2.id;
    }
    /**
     * Validates if the given code has basic syntax hygiene for the target language.
     */
    static validateCodeHygiene(code, languageId) {
      if (!code || code.trim().length === 0) {
        return { valid: false, reason: "Generated code is empty" };
      }
      const trimmed = code.trim();
      if (trimmed.startsWith("```") || trimmed.endsWith("```")) {
        return { valid: false, reason: "Code contains raw markdown code fence markers" };
      }
      const cStyleLanguages = ["cpp", "c", "java", "csharp", "javascript", "typescript", "rust", "kotlin", "swift", "php", "dart", "scala", "go"];
      const norm = this.normalizeLanguageId(languageId);
      if (cStyleLanguages.includes(norm)) {
        let curly = 0;
        let square = 0;
        let round = 0;
        let inString = false;
        let stringChar = "";
        let inLineComment = false;
        let inBlockComment = false;
        for (let i = 0; i < trimmed.length; i++) {
          const ch = trimmed[i];
          const next = trimmed[i + 1] || "";
          if (!inString && !inBlockComment && ch === "/" && next === "/") {
            inLineComment = true;
            i++;
            continue;
          }
          if (inLineComment && ch === "\n") {
            inLineComment = false;
            continue;
          }
          if (!inString && !inLineComment && ch === "/" && next === "*") {
            inBlockComment = true;
            i++;
            continue;
          }
          if (inBlockComment && ch === "*" && next === "/") {
            inBlockComment = false;
            i++;
            continue;
          }
          if (inLineComment || inBlockComment) continue;
          if ((ch === '"' || ch === "'" || ch === "`") && (i === 0 || trimmed[i - 1] !== "\\")) {
            if (!inString) {
              inString = true;
              stringChar = ch;
            } else if (stringChar === ch) {
              inString = false;
            }
            continue;
          }
          if (inString) continue;
          if (ch === "{") curly++;
          else if (ch === "}") curly--;
          else if (ch === "[") square++;
          else if (ch === "]") square--;
          else if (ch === "(") round++;
          else if (ch === ")") round--;
          if (curly < 0 || square < 0 || round < 0) {
            return { valid: false, reason: `Unmatched closing bracket '${ch}' found in code` };
          }
        }
        if (curly !== 0) return { valid: false, reason: `Unbalanced curly braces { } (count difference: ${curly})` };
        if (round !== 0) return { valid: false, reason: `Unbalanced parentheses ( ) (count difference: ${round})` };
      }
      return { valid: true };
    }
  };

  // src/content/leetcode-adapter.ts
  var LeetCodeAdapter = class {
    /**
     * Checks if the given or current URL matches a supported LeetCode problem page.
     */
    static isLeetCodeProblemPage(url = window.location.href) {
      return /^https?:\/\/(www\.)?leetcode\.(com|cn)\/problems\/[a-z0-9_-]+/i.test(url);
    }
    /**
     * Extracts the problem slug from URL.
     */
    static extractSlug(url = window.location.href) {
      const match = url.match(/\/problems\/([a-z0-9_-]+)/i);
      return match ? match[1].toLowerCase() : "";
    }
    /**
     * Primary DOM extraction method with multiple resilient selector fallbacks.
     */
    static extractFromDOM() {
      const partial = {
        url: window.location.href,
        slug: this.extractSlug(),
        examples: [],
        constraints: []
      };
      const titleSelectors = [
        '[data-track-load="description_content"] h4',
        ".text-title-large",
        'div[class*="title-large"]',
        'div[class*="text-title"]',
        'div[class*="title__"]',
        'a[href*="/problems/"]'
      ];
      for (const sel of titleSelectors) {
        const el = document.querySelector(sel);
        if (el && el.textContent && el.textContent.trim()) {
          const text = el.textContent.trim();
          if (text.length > 2 && !text.includes("LeetCode")) {
            partial.title = text;
            break;
          }
        }
      }
      if (!partial.title) {
        const docTitle = document.title;
        if (docTitle && docTitle.includes("- LeetCode")) {
          partial.title = docTitle.replace("- LeetCode", "").trim();
        } else {
          const slug = partial.slug || "";
          partial.title = slug.replace(/-/g, " ").replace(/\b\w/g, (l) => l.toUpperCase());
        }
      }
      const diffSelectors = [
        '.text-difficulty-easy, [class*="text-difficulty-easy"], [class*="text-easy"]',
        '.text-difficulty-medium, [class*="text-difficulty-medium"], [class*="text-medium"]',
        '.text-difficulty-hard, [class*="text-difficulty-hard"], [class*="text-hard"]'
      ];
      if (document.querySelector(diffSelectors[0])) {
        partial.difficulty = "Easy";
      } else if (document.querySelector(diffSelectors[1])) {
        partial.difficulty = "Medium";
      } else if (document.querySelector(diffSelectors[2])) {
        partial.difficulty = "Hard";
      } else {
        const badges = document.querySelectorAll("div, span");
        for (const b of Array.from(badges)) {
          const txt = b.textContent?.trim();
          if (txt === "Easy" || txt === "Medium" || txt === "Hard") {
            partial.difficulty = txt;
            break;
          }
        }
        if (!partial.difficulty) {
          partial.difficulty = "Unknown";
        }
      }
      const descSelectors = [
        '[data-track-load="description_content"]',
        ".elfjS",
        'div[class*="content__"]',
        'div[class*="description__"]',
        ".question-content"
      ];
      let descEl = null;
      for (const sel of descSelectors) {
        descEl = document.querySelector(sel);
        if (descEl) break;
      }
      if (descEl) {
        const rawHtml = descEl.innerHTML;
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = rawHtml;
        const exampleBlocks = tempDiv.querySelectorAll('pre, .example-block, div[class*="example"]');
        exampleBlocks.forEach((ex) => {
          const text = ex.textContent?.trim();
          if (text && (text.includes("Input:") || text.includes("Output:"))) {
            partial.examples.push(text);
          }
        });
        const listItems = tempDiv.querySelectorAll("ul li, ol li");
        listItems.forEach((li) => {
          const txt = li.textContent?.trim();
          if (txt && (txt.includes("<=") || txt.includes(">=") || txt.includes("length") || txt.includes("consists"))) {
            partial.constraints.push(txt);
          }
        });
        partial.statement = (tempDiv.innerText || tempDiv.textContent || "").trim();
      }
      const langBtn = document.querySelector('button[id*="headlessui-listbox-button"], button[class*="rounded"][class*="px-"][aria-haspopup="listbox"]');
      if (langBtn && langBtn.textContent) {
        const langText = langBtn.textContent.trim();
        partial.editorLanguage = LanguageRegistry.normalizeLanguageId(langText);
      } else {
        const codeEditorLang = document.querySelector("[data-mode-id]");
        if (codeEditorLang) {
          partial.editorLanguage = LanguageRegistry.normalizeLanguageId(codeEditorLang.getAttribute("data-mode-id") || "python3");
        } else {
          partial.editorLanguage = "python3";
        }
      }
      const viewLines = document.querySelector(".monaco-editor .view-lines");
      if (viewLines) {
        partial.starterCode = viewLines.textContent || "";
      }
      return partial;
    }
    /**
     * Resilient GraphQL fallback query executed directly in page context.
     */
    static async fetchFromGraphQL(slug) {
      if (!slug) return null;
      try {
        const query = `
        query questionData($titleSlug: String!) {
          question(titleSlug: $titleSlug) {
            questionId
            title
            titleSlug
            content
            difficulty
            exampleTestcaseList
            topicTags {
              name
              slug
            }
            codeSnippets {
              lang
              langSlug
              code
            }
          }
        }
      `;
        const response = await fetch("/graphql", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            query,
            variables: { titleSlug: slug }
          })
        });
        if (!response.ok) return null;
        const result = await response.json();
        const q = result.data?.question;
        if (!q) return null;
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = q.content || "";
        const statement = (tempDiv.innerText || tempDiv.textContent || "").trim();
        const examples = [];
        tempDiv.querySelectorAll("pre, .example-block").forEach((el) => {
          if (el.textContent) examples.push(el.textContent.trim());
        });
        const constraints = [];
        tempDiv.querySelectorAll("ul li").forEach((el) => {
          const txt = el.textContent?.trim();
          if (txt) constraints.push(txt);
        });
        const tags = (q.topicTags || []).map((t) => t.name);
        return {
          title: q.title || slug,
          slug: q.titleSlug || slug,
          difficulty: q.difficulty || "Unknown",
          statement,
          examples,
          constraints,
          tags
        };
      } catch {
        return null;
      }
    }
    /**
     * Master context extraction combining DOM scraping and GraphQL fallback.
     */
    static async extractProblemContext() {
      if (!this.isLeetCodeProblemPage()) {
        return {
          success: false,
          error: "Active tab is not a supported LeetCode problem page (URL must match leetcode.com/problems/*)"
        };
      }
      const domContext = this.extractFromDOM();
      const slug = domContext.slug || this.extractSlug();
      const isDOMComplete = !!(domContext.title && domContext.statement && domContext.statement.length > 50);
      let finalContext;
      let graphqlFallbackUsed = false;
      if (!isDOMComplete && slug) {
        const gqlContext = await this.fetchFromGraphQL(slug);
        if (gqlContext) {
          graphqlFallbackUsed = true;
          finalContext = {
            title: gqlContext.title || domContext.title || slug,
            slug,
            url: window.location.href,
            difficulty: gqlContext.difficulty || domContext.difficulty || "Unknown",
            statement: gqlContext.statement || domContext.statement || "Problem description is loading...",
            examples: gqlContext.examples && gqlContext.examples.length > 0 ? gqlContext.examples : domContext.examples || [],
            constraints: gqlContext.constraints && gqlContext.constraints.length > 0 ? gqlContext.constraints : domContext.constraints || [],
            starterCode: domContext.starterCode || "",
            editorLanguage: domContext.editorLanguage || "python3",
            tags: gqlContext.tags || [],
            detectedAt: Date.now()
          };
        } else {
          finalContext = {
            title: domContext.title || slug,
            slug,
            url: window.location.href,
            difficulty: domContext.difficulty || "Unknown",
            statement: domContext.statement || "Problem description not yet fully rendered.",
            examples: domContext.examples || [],
            constraints: domContext.constraints || [],
            starterCode: domContext.starterCode || "",
            editorLanguage: domContext.editorLanguage || "python3",
            detectedAt: Date.now()
          };
        }
      } else {
        finalContext = {
          title: domContext.title || slug,
          slug,
          url: window.location.href,
          difficulty: domContext.difficulty || "Unknown",
          statement: domContext.statement || "",
          examples: domContext.examples || [],
          constraints: domContext.constraints || [],
          starterCode: domContext.starterCode || "",
          editorLanguage: domContext.editorLanguage || "python3",
          detectedAt: Date.now()
        };
      }
      return {
        success: true,
        context: finalContext,
        diagnostics: {
          domTitleFound: !!domContext.title,
          domContentFound: !!domContext.statement,
          editorFound: !!document.querySelector(".monaco-editor"),
          graphqlFallbackUsed,
          url: window.location.href
        }
      };
    }
  };

  // src/content/editor-adapter.ts
  var EditorAdapter = class {
    /**
     * Reads current editor state using Monaco bridge with DOM fallback.
     */
    static async getEditorState() {
      return new Promise((resolve) => {
        let resolved = false;
        const handler = (event) => {
          if (resolved) return;
          resolved = true;
          window.removeEventListener("LEETCODE_COPILOT_EDITOR_STATE_RESULT", handler);
          const detail = event.detail || {};
          if (detail.found) {
            const currentCode = detail.code || "";
            const hasUserModifications = currentCode.trim().length > 100;
            resolve({
              found: true,
              language: detail.language || "plaintext",
              currentCode,
              hasUserModifications,
              lineCount: detail.lineCount || 0,
              mechanismAvailable: "monaco-api"
            });
          } else {
            resolve(this.getDOMFallbackState());
          }
        };
        window.addEventListener("LEETCODE_COPILOT_EDITOR_STATE_RESULT", handler);
        window.dispatchEvent(new CustomEvent("LEETCODE_COPILOT_GET_EDITOR_STATE"));
        setTimeout(() => {
          if (!resolved) {
            resolved = true;
            window.removeEventListener("LEETCODE_COPILOT_EDITOR_STATE_RESULT", handler);
            resolve(this.getDOMFallbackState());
          }
        }, 500);
      });
    }
    static getDOMFallbackState() {
      const editorEl = document.querySelector(".monaco-editor");
      const viewLines = document.querySelector(".monaco-editor .view-lines");
      const currentCode = viewLines ? viewLines.textContent || "" : "";
      return {
        found: !!editorEl,
        language: "unknown",
        currentCode,
        hasUserModifications: currentCode.trim().length > 100,
        lineCount: currentCode.split("\n").length,
        mechanismAvailable: editorEl ? "monaco-dom-paste" : "clipboard-fallback"
      };
    }
    /**
     * Inserts code into LeetCode Monaco editor with verification, overwrite protection, and fallbacks.
     */
    static async insertCode(options) {
      const { code, forceOverwrite } = options;
      const state = await this.getEditorState();
      if (!forceOverwrite && state.hasUserModifications && state.currentCode.trim().length > 150) {
        return {
          success: false,
          mechanismUsed: state.mechanismAvailable,
          verified: false,
          linesInserted: 0,
          needsConfirmation: true,
          previousCodeSnippet: state.currentCode.substring(0, 120),
          message: "Editor already contains existing code. Please confirm before overwriting."
        };
      }
      try {
        const monacoResult = await this.insertViaMonacoAPI(code);
        if (monacoResult.success && monacoResult.verified) {
          return monacoResult;
        }
      } catch {
      }
      try {
        const domResult = await this.insertViaDOMSimulation(code);
        if (domResult.success && domResult.verified) {
          return domResult;
        }
      } catch {
      }
      try {
        await navigator.clipboard.writeText(code);
        return {
          success: true,
          mechanismUsed: "clipboard-fallback",
          verified: false,
          linesInserted: code.split("\n").length,
          message: "Direct editor insertion was blocked by browser sandbox. Code has been copied to your clipboard! Paste directly with Ctrl+V / Cmd+V."
        };
      } catch (e) {
        return {
          success: false,
          mechanismUsed: "clipboard-fallback",
          verified: false,
          linesInserted: 0,
          message: `Failed to insert or copy code: ${e.message}`
        };
      }
    }
    static insertViaMonacoAPI(code) {
      return new Promise((resolve, reject) => {
        let resolved = false;
        const handler = (event) => {
          if (resolved) return;
          resolved = true;
          window.removeEventListener("LEETCODE_COPILOT_INSERT_RESULT", handler);
          const detail = event.detail || {};
          if (detail.success && detail.verified) {
            resolve({
              success: true,
              mechanismUsed: "monaco-api",
              verified: true,
              linesInserted: detail.linesInserted || code.split("\n").length,
              previousCodeSnippet: detail.previousCodeSnippet,
              message: "Code successfully inserted and verified in LeetCode Monaco editor!"
            });
          } else {
            reject(new Error(detail.message || "Monaco insertion verification failed"));
          }
        };
        window.addEventListener("LEETCODE_COPILOT_INSERT_RESULT", handler);
        window.dispatchEvent(new CustomEvent("LEETCODE_COPILOT_INSERT_CODE", { detail: { code } }));
        setTimeout(() => {
          if (!resolved) {
            resolved = true;
            window.removeEventListener("LEETCODE_COPILOT_INSERT_RESULT", handler);
            reject(new Error("Monaco API insertion response timed out"));
          }
        }, 1e3);
      });
    }
    static async insertViaDOMSimulation(code) {
      const textarea = document.querySelector(".monaco-editor textarea.inputarea");
      if (!textarea) {
        throw new Error("Monaco textarea.inputarea element not found");
      }
      textarea.focus();
      document.execCommand("selectAll", false, void 0);
      const inserted = document.execCommand("insertText", false, code);
      await new Promise((r) => setTimeout(r, 200));
      const viewLines = document.querySelector(".monaco-editor .view-lines");
      const newContent = viewLines?.textContent || "";
      const linesInserted = code.split("\n").length;
      const verified = inserted && newContent.length > 20;
      return {
        success: verified,
        mechanismUsed: "monaco-dom-paste",
        verified,
        linesInserted,
        message: verified ? "Code inserted into editor via DOM simulation" : "DOM simulation could not verify insertion"
      };
    }
  };

  // src/content/content-script.ts
  function injectMonacoBridge() {
    const existing = document.getElementById("leetcode-ai-copilot-inject");
    if (existing) return;
    try {
      const script = document.createElement("script");
      script.id = "leetcode-ai-copilot-inject";
      script.src = chrome.runtime.getURL("editor-inject.js");
      (document.head || document.documentElement).appendChild(script);
    } catch (err) {
      console.warn("[LeetCode AI Copilot] Could not inject editor bridge:", err);
    }
  }
  injectMonacoBridge();
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    (async () => {
      try {
        switch (message.type) {
          case "PING": {
            sendResponse({
              success: true,
              data: {
                url: window.location.href,
                isProblemPage: LeetCodeAdapter.isLeetCodeProblemPage(),
                titleSlug: LeetCodeAdapter.extractSlug()
              }
            });
            break;
          }
          case "EXTRACT_PROBLEM_CONTEXT": {
            const result = await LeetCodeAdapter.extractProblemContext();
            sendResponse({
              success: result.success,
              data: result.context,
              error: result.error
            });
            break;
          }
          case "GET_EDITOR_STATE": {
            const state = await EditorAdapter.getEditorState();
            sendResponse({
              success: true,
              data: state
            });
            break;
          }
          case "INSERT_CODE_TO_EDITOR": {
            const result = await EditorAdapter.insertCode(message.payload);
            sendResponse({
              success: result.success,
              data: result,
              error: result.success ? void 0 : result.message
            });
            break;
          }
          default:
            sendResponse({ success: false, error: "Unknown message type" });
        }
      } catch (err) {
        sendResponse({
          success: false,
          error: err.message || "Error processing message in content script"
        });
      }
    })();
    return true;
  });
  var lastUrl = window.location.href;
  var observer = new MutationObserver(() => {
    if (window.location.href !== lastUrl) {
      lastUrl = window.location.href;
      injectMonacoBridge();
    }
  });
  observer.observe(document, { subtree: true, childList: true });
  window.addEventListener("popstate", () => {
    injectMonacoBridge();
  });
})();
